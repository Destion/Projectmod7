---README---

NOTE: The application.py file uses 3 python liberaries:
sys, os and threading to present the user with a nice interface.
If this is not allowed the application.py file can also be removed.
In this case, read point 4 from the list below

NOTE 2: RUN IN PYTHON 3 
(2 will NOT work)

1. How to use the application
	- Place the test instances in the same folder as the python files
	- run application.py
	- the application will print id's and filenames of all graph files in the directory
	- type a command (commands should be typed without the '' ):
		- type 'aut <file-id>' to get the automorphism counts and the isomorphism groups
		- type 'iso <file-id>' to get the isomorphism groups
		- type 'help' to list all commands


2. How does it work
	- The application loads the file
	- it will divide the graph list into rough groups using the week1 algorithm
	- using these groups, it will compare each of the graphs in each group further
		by using the extended color refinement (using fast partitioning) until 
		a bijection has been found.
	- if a graph is not isomorph to any group, it will be placed in a new group
		for this group the number of automorphisms can be calculated.
	- the algorithm will count automorphisms in trees more efficiently
	- when done, the algorithm prints the outcome and returns the groups

3. Features
	- Command line interface
	- Detect trees (you can use the 'info <file-id>' command to read this manually
	- Count tree automorphisms more efficiently (than the method for other graphs)

4. When "application.py" is not allowed
	- Edit "gerbenBetterRefinement.py"
	- At the bottom of the file (after if __name__ == "__main__":)
		- change the file to be opened in "loadgraph"
		- disregard the code in comments
		- alter the second argument of "getIsomorphismGroups" to the requested setup
			True = count automorphisms
			False = only display isomorphic groups
	- run the "gerbenBetterRefinement.py" file
		
